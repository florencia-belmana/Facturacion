package facturacion.facturacion.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.crypto.Data;


@Entity
@Table(name = "COMPROBANTE")
public class Comprobante {

        //Vars.

        @Column(name = "COMRPOBANTE")
        @Id
        private int comprobanteid;

        @Column(name = "FECHA")
        private Data fecha;

        @Column(name = "CANTIDAD")
        private int cantidad;

        @Column(name = "TOTAL")
        private float total;

        @Column(name = "CLIENTE_ID")
        private Cliente clienteid;


        //CONSTRUCTORES

        public Comprobante() {
        }

        public Comprobante(int comprobanteid, Data fecha, int cantidad, float total, Cliente clienteid) {
                this.comprobanteid = comprobanteid;
                this.fecha = fecha;
                this.cantidad = cantidad;
                this.total = total;
                this.clienteid = clienteid;
        }


        //getters&setters


        public int getComprobanteid() {
                return comprobanteid;
        }

        public void setComprobanteid(int comprobanteid) {
                this.comprobanteid = comprobanteid;
        }

        public Data getFecha() {
                return fecha;
        }

        public void setFecha(Data fecha) {
                this.fecha = fecha;
        }

        public int getCantidad() {
                return cantidad;
        }

        public void setCantidad(int cantidad) {
                this.cantidad = cantidad;
        }

        public float getTotal() {
                return total;
        }

        public void setTotal(float total) {
                this.total = total;
        }

        public Cliente getClienteid() {
                return clienteid;
        }

        public void setClienteid(Cliente clienteid) {
                this.clienteid = clienteid;
        }
}


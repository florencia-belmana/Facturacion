package facturacion.facturacion.service;

import facturacion.facturacion.model.Comprobante;
import facturacion.facturacion.repository.ComprobanteRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


public class ComprobanteServiceImpl implements ComprobanteService{

    @Autowired
    private ComprobanteRepository repository;

    //metodos//
    @Override
    public Comprobante crear(Comprobante comprobante) throws Exception {
        return comprobante;
        //  return repository.save(comprobante);
        // MOSTRAR VENTA, DEALLE, FECHA (EXTERNO, DSP), CLIENTE, LISA DE PROD. Y SUS CARAC. TOTAL
    }

    @Override
    public List<Comprobante> buscarTodosLosComprobantes() {
        return repository.findAll();
    }
    @Override
    public Comprobante buscarComprobantePorId(int comprobanteid) {
        return repository.findById(comprobanteid).orElse(null);
    }
    @Override
    public Comprobante actualizar(Comprobante comprobante) throws Exception {
        if (buscarComprobantePorId(comprobante.getComprobanteid()) != null){

            return repository.save(comprobante);
        } else {
        throw new Exception("El comprobante ya existe");
        }
    }


}


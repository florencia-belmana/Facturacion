package facturacion.facturacion.service;

import facturacion.facturacion.model.Comprobante;
import facturacion.facturacion.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;

public class ComprobanteServiceImpl implements ComprobanteService{

    @Autowired
    private ClienteRepository repository;
    @Override
    public Comprobante crear(Comprobante comprobante) throws Exception {
        return comprobante;
      //  return repository.save(comprobante);

        //MOSTRAR VENTA, DEALLE, FECHA (EXTERNO, DSP), CLIENTE, LISA DE PROD. Y SUS CARAC. TOTAL 
    }
}


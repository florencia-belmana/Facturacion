package facturacion.facturacion.service;

import facturacion.facturacion.model.Comprobante;

public interface ComprobanteService {

    Comprobante crear(Comprobante comprobante) throws Exception;
}

package facturacion.facturacion.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.crypto.Data;

@Entity
@Table(name = "comprobante")
public class Comprobante {


        //Creacion de vars.

        @Column(name = "COMRPOBANTE")
        @Id
        private int comprobanteid;

        @Column(name = "FECHA")
        private Data fecha;

        @Column(name = "cantidad")
        private int cantidad;

        @Column(name = "total")
        private float total;

        @Column(name = "CLIENTE_ID")
        private int clienteid;


}


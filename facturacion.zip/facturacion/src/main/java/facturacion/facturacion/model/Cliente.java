package facturacion.facturacion.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "facturacion/cliente")

public class Cliente {
    @Column
    @Id
    private int clienteId;

    @Column
    private int dni;

    @Column
    private String nombre;

    @Column
    private String apellido;

    //CONSTRUCTORES
    public Cliente() {
    }

    public Cliente(int clienteId, int dni, String nombre, String apellido) {
        this.clienteId = clienteId;
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
    }
}


